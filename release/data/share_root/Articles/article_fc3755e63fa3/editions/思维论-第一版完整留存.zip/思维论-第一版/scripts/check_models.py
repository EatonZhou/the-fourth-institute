from fractions import Fraction
from functools import lru_cache
from heapq import heappop, heappush
from itertools import combinations, product
from math import ceil, exp, log, log2
import json
import random


def check_recombination():
    result = {}
    for routes, components, probability in [(2, 2, Fraction(1, 2)), (4, 3, Fraction(1, 4))]:
        whole = Fraction(0)
        mixed = Fraction(0)
        count = routes * components
        for outcomes in product((0, 1), repeat=count):
            successes = sum(outcomes)
            mass = probability**successes * (1 - probability)**(count - successes)
            all_route = any(all(outcomes[route * components + component] for component in range(components)) for route in range(routes))
            all_component = all(any(outcomes[route * components + component] for route in range(routes)) for component in range(components))
            assert not all_route or all_component
            whole += mass * all_route
            mixed += mass * all_component
        assert whole == 1 - (1 - probability**components)**routes
        assert mixed == (1 - (1 - probability)**routes)**components
        result[f"{routes}x{components}"] = {"whole": str(whole), "mixed": str(mixed), "whole_decimal": float(whole), "mixed_decimal": float(mixed), "exhaustive_outcomes": 2**count}
    return result


def schedule(durations, predecessors, processors):
    remaining = set(range(len(durations)))
    completed = set()
    running = []
    clock = 0
    while remaining or running:
        ready = sorted(task for task in remaining if predecessors[task] <= completed)
        for task in ready[:processors - len(running)]:
            heappush(running, (clock + durations[task], task))
            remaining.remove(task)
        assert running
        clock = running[0][0]
        while running and running[0][0] == clock:
            _, task = heappop(running)
            completed.add(task)
    return clock


def check_scheduling(generator):
    checked = 0
    for size in range(1, 11):
        for _ in range(35):
            durations = [generator.randint(1, 9) for _ in range(size)]
            predecessors = [{earlier for earlier in range(task) if generator.random() < 0.3} for task in range(size)]
            paths = []
            for task in range(size):
                paths.append(durations[task] + max((paths[parent] for parent in predecessors[task]), default=0))
            work, span = sum(durations), max(paths)
            for processors in range(1, 5):
                elapsed = schedule(durations, predecessors, processors)
                assert elapsed >= max(Fraction(work, processors), span)
                assert elapsed <= Fraction(work, processors) + Fraction(processors - 1, processors) * span
                checked += 1
    return checked


def check_realization(generator):
    checked = 0
    for size in range(1, 9):
        for _ in range(20):
            inputs = []
            for operation in range(size):
                if operation and generator.random() < 0.7:
                    parent = generator.randrange(operation)
                    sequence = inputs[parent] + (parent,)
                else:
                    sequence = tuple(generator.sample(list(range(-2, operation)), generator.randint(1, min(3, operation + 2))))
                inputs.append(sequence)
            adjacency = {source: [target for target in range(source + 1, size) if inputs[target] == inputs[source] + (source,)] for source in range(size)}

            @lru_cache(None)
            def maximum_matching(source, used):
                if source == size:
                    return 0
                best = maximum_matching(source + 1, used)
                for target in adjacency[source]:
                    if not (used & (1 << target)):
                        best = max(best, 1 + maximum_matching(source + 1, used | (1 << target)))
                return best

            @lru_cache(None)
            def minimum_members(operation, tails):
                if operation == size:
                    return len(tails)
                best = minimum_members(operation + 1, tuple(sorted(tails + (operation,))))
                for position, tail in enumerate(tails):
                    if operation in adjacency[tail]:
                        updated = list(tails)
                        updated[position] = operation
                        best = min(best, minimum_members(operation + 1, tuple(sorted(updated))))
                return best

            assert minimum_members(0, ()) == size - maximum_matching(0, 0)
            seeds = [generator.randrange(100) for _ in range(size)]
            initial = {-2: 3, -1: 7}

            def evaluate(order):
                values = dict(initial)
                for operation in order:
                    values[operation] = seeds[operation] + sum((position + 1) * values[fragment] for position, fragment in enumerate(inputs[operation]))
                return values

            remaining = set(range(size))
            available = set(initial)
            order = []
            while remaining:
                ready = [operation for operation in remaining if set(inputs[operation]) <= available]
                operation = generator.choice(ready)
                order.append(operation)
                available.add(operation)
                remaining.remove(operation)
            assert evaluate(order) == evaluate(range(size))
            checked += 1
    return checked


def check_exposure(generator):
    for size in range(1, 31):
        lengths = [generator.randint(0, 30) for _ in range(size)]
        initial = generator.randint(0, 30)
        direct = sum(initial + sum(lengths[:step]) for step in range(size))
        formula = size * initial + sum((size - index - 1) * length for index, length in enumerate(lengths[:-1]))
        assert direct == formula
    assert 5 * 10 + 4 * 2 + 3 * 4 + 2 * 3 + 1 == 77
    return 30


def entropy(probabilities):
    return -sum(probability * log2(probability) for probability in probabilities if probability > 0)


def mutual_information(joint):
    first = [sum(row) for row in joint]
    second = [sum(row[column] for row in joint) for column in range(len(joint[0]))]
    return entropy(first) + entropy(second) - entropy([value for row in joint for value in row])


def check_information(generator):
    assert abs(mutual_information([[0.25, 0.25], [0.25, 0.25]])) < 1e-12
    assert abs(mutual_information([[0.25, 0, 0, 0.25], [0, 0.25, 0.25, 0]]) - 1) < 1e-12
    for _ in range(100):
        raw = [[generator.randint(1, 20) for _ in range(4)] for _ in range(3)]
        total = sum(map(sum, raw))
        joint = [[value / total for value in row] for row in raw]
        channel = []
        for _ in range(4):
            values = [generator.randint(1, 20) for _ in range(2)]
            channel.append([value / sum(values) for value in values])
        transformed = [[sum(joint[label][observation] * channel[observation][output] for observation in range(4)) for output in range(2)] for label in range(3)]
        assert mutual_information(transformed) <= mutual_information(joint) + 1e-12
    return 102


def check_coverage(generator):
    checked = 0
    for size in range(2, 9):
        for _ in range(20):
            coverage = [{item for item in range(9) if generator.random() < 0.4} for _ in range(size)]
            weights = [generator.randint(1, 5) for _ in range(9)]

            def value(selected):
                union = set().union(*(coverage[index] for index in selected)) if selected else set()
                return sum(weights[item] for item in union)

            for budget in range(1, min(3, size) + 1):
                selected = []
                for _ in range(budget):
                    chosen = max((index for index in range(size) if index not in selected), key=lambda index: value(selected + [index]))
                    selected.append(chosen)
                optimum = max(value(combination) for combination in combinations(range(size), budget))
                factor = 1 - (1 - Fraction(1, budget))**budget
                assert value(selected) >= factor * optimum
                checked += 1
    return checked


def check_exploration():
    probability = Fraction(1, 5)
    assert 1 - (1 - probability)**5 == Fraction(2101, 3125)
    assert Fraction(1, 2) <= 1 - Fraction(1, 2)**10
    for branches in range(1, 10):
        budget, overhead, rate = 20, 1, 0.1
        per_branch = 1 - exp(-rate * (budget / branches - overhead))
        assert abs(1 - (1 - per_branch)**branches - (1 - exp(-rate * (budget - branches * overhead)))) < 1e-12
    assert ceil(log(2 * 8 / 0.05) / (2 * 0.1**2)) == 289
    return 12


def main():
    generator = random.Random(20260913)
    result = {
        "status": "passed",
        "seed": 20260913,
        "recombination": check_recombination(),
        "scheduling_instances": check_scheduling(generator),
        "realization_instances": check_realization(generator),
        "exposure_instances": check_exposure(generator),
        "information_instances": check_information(generator),
        "coverage_instances": check_coverage(generator),
        "exploration_checks": check_exploration(),
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
