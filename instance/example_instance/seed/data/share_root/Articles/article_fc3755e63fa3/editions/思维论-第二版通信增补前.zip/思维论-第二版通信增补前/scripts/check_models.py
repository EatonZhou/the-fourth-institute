from collections import Counter
from decimal import Decimal, ROUND_CEILING, localcontext
from fractions import Fraction
from itertools import combinations, product
from math import ceil, comb, exp, log, sqrt
from pathlib import Path
import csv
import json
import random


ROOT = Path(__file__).resolve().parents[1]


def binomial_mass(trials, successes, probability):
    return comb(trials, successes) * probability ** successes * (1 - probability) ** (trials - successes)


def acceptance(trials, probability):
    return sum((binomial_mass(trials, successes, probability)
                for successes in range((trials + 1) // 2, trials + 1)), Fraction())


def decimal_fraction(value):
    return Decimal(value.numerator) / Decimal(value.denominator)


def check_contract_amplification():
    cases = 0
    smallest_slack = Decimal(1)
    for stages, proposal, margin, tolerance in product(
        (1, 3, 7), (Fraction(1, 4), Fraction(1, 2), Fraction(3, 4)),
        (Fraction(1, 4),), (Fraction(1, 10), Fraction(1, 20))
    ):
        attempts = ceil(log(2 * stages / float(tolerance)) / float(proposal))
        checks = ceil(log(2 * stages * attempts / float(tolerance)) / (2 * float(margin) ** 2))
        good_accept = decimal_fraction(acceptance(checks, Fraction(1, 2) + margin))
        bad_accept = decimal_fraction(acceptance(checks, Fraction(1, 2) - margin))
        candidate_probability = decimal_fraction(proposal)
        accepted_good = candidate_probability * good_accept
        accepted_bad = (1 - candidate_probability) * bad_accept
        reject = 1 - accepted_good - accepted_bad
        stage_success = accepted_good * (1 - reject ** attempts) / (1 - reject)
        failure = 1 - stage_success ** stages
        assert failure <= decimal_fraction(tolerance)
        slack = decimal_fraction(tolerance) - failure
        smallest_slack = min(smallest_slack, slack)
        cases += 1
    for proposal, checks, attempts in product((Fraction(1, 4), Fraction(2, 3)), (1, 3), (1, 2, 3)):
        good_accept = acceptance(checks, Fraction(3, 4))
        bad_accept = acceptance(checks, Fraction(1, 4))
        accepted_good = proposal * good_accept
        rejected = 1 - accepted_good - (1 - proposal) * bad_accept
        by_recurrence = Fraction()
        for attempt in range(attempts):
            by_recurrence += rejected ** attempt * accepted_good
        by_formula = accepted_good * (1 - rejected ** attempts) / (1 - rejected)
        assert by_recurrence == by_formula
        cases += 1
    return {"cases": cases, "minimum_bound_slack": str(smallest_slack),
            "scope": "独立检查特例的精确二项概率；一般条件余量由正文证明"}


def check_unknown_chain():
    probability = Fraction(3, 4)
    cases = 0
    for length, repeats, variant in product(range(1, 5), (1, 3), (0, 1)):
        truth_tables = [((1, 0) if (index + variant) % 2 else (0, 0)) for index in range(length)]
        true_value = 0
        true_trace = []
        for table in truth_tables:
            true_value = table[true_value]
            true_trace.append(true_value)
        exact_success = Fraction()
        for correctness in product((0, 1), repeat=length * repeats):
            current = 0
            trace = []
            for index, table in enumerate(truth_tables):
                predicted_truth = table[current]
                votes = [predicted_truth if correct else 1 - predicted_truth
                         for correct in correctness[index * repeats:(index + 1) * repeats]]
                current = int(sum(votes) > repeats / 2)
                trace.append(current)
            if trace == true_trace:
                successes = sum(correctness)
                exact_success += probability ** successes * (1 - probability) ** (len(correctness) - successes)
            cases += 1
        assert exact_success == acceptance(repeats, probability) ** length
    return {"enumerated_noise_patterns": cases, "lengths": [1, 2, 3, 4], "local_repetitions": [1, 3]}


def check_verification_lower_bound():
    cases = 0
    for margin, trials in product((Fraction(1, 10), Fraction(1, 4)), range(1, 31)):
        good = Fraction(1, 2) + margin
        positive_mass = [binomial_mass(trials, count, good) for count in range(trials + 1)]
        negative_mass = [binomial_mass(trials, count, 1 - good) for count in range(trials + 1)]
        variation = sum(abs(left - right) for left, right in zip(positive_mass, negative_mass)) / 2
        error = sum(positive_mass[:(trials + 1) // 2])
        if trials % 2 == 0:
            error += positive_mass[trials // 2] / 2
        assert error == (1 - variation) / 2
        divergence = 2 * float(margin) * log((1 + 2 * float(margin)) / (1 - 2 * float(margin)))
        decision_divergence = (1 - 2 * float(error)) * log((1 - float(error)) / float(error))
        assert trials * divergence + 1e-12 >= decision_divergence
        assert divergence <= 16 * float(margin) ** 2 + 1e-12
        cases += 1
    shared_error = Fraction(1, 5)
    for members in (1, 3, 5, 101):
        states = [(0, 1 - shared_error), (1, shared_error)]
        majority_error = sum(weight for wrong, weight in states if sum([wrong] * members) > members / 2)
        assert majority_error == shared_error
        cases += 1
    return {"cases": cases, "checks": ["二点界等号", "检验相对熵下界", "共同错误不被多数消除"]}


def solve_mdp(transitions, rewards, horizon, prescribed=None):
    state_count = len(transitions)
    values = [Fraction()] * state_count
    policies = []
    for stage in range(horizon):
        new_values = []
        policy = []
        for state in range(state_count):
            action_values = [rewards[state][action] + sum(probability * values[next_state]
                             for next_state, probability in enumerate(kernel))
                             for action, kernel in enumerate(transitions[state])]
            chosen = prescribed[stage][state] if prescribed is not None else max(range(len(action_values)), key=action_values.__getitem__)
            new_values.append(action_values[chosen])
            policy.append(chosen)
        values = new_values
        policies.append(policy)
    return values, policies


def check_abstraction():
    generator = random.Random(20260913)
    cases = 0
    for iteration in range(100):
        model = []
        actual = []
        model_rewards = []
        actual_rewards = []
        for state in range(2):
            model.append([])
            actual.append([])
            model_rewards.append([])
            actual_rewards.append([])
            for action in range(2):
                center = generator.randrange(2, 9)
                displacement = generator.choice((-1, 0, 1))
                probability = Fraction(center, 10)
                altered = Fraction(center + displacement, 10)
                model[state].append([probability, 1 - probability])
                actual[state].append([altered, 1 - altered])
                reward = generator.randrange(1, 10)
                model_rewards[state].append(Fraction(reward, 10))
                actual_rewards[state].append(Fraction(reward + generator.choice((-1, 0, 1)), 10))
        horizon = generator.randrange(1, 7)
        model_values, policy = solve_mdp(model, model_rewards, horizon)
        actual_values, _ = solve_mdp(actual, actual_rewards, horizon)
        lifted_values, _ = solve_mdp(actual, actual_rewards, horizon, policy)
        bound = Fraction(horizon, 10) + Fraction(horizon * (horizon - 1), 20)
        for state in range(2):
            assert abs(model_values[state] - lifted_values[state]) <= bound
            assert actual_values[state] - lifted_values[state] <= 2 * bound
        expanded_transitions = []
        expanded_rewards = []
        for state in range(4):
            abstract = state // 2
            expanded_transitions.append([[kernel[0] / 2, kernel[0] / 2, kernel[1] / 2, kernel[1] / 2]
                                         for kernel in model[abstract]])
            expanded_rewards.append(model_rewards[abstract])
        expanded_values, _ = solve_mdp(expanded_transitions, expanded_rewards, horizon)
        assert all(expanded_values[state] == model_values[state // 2] for state in range(4))
        cases += 1
    return {"finite_mdps": cases, "seed": 20260913, "checks": ["精确商状态", "近似策略误差", "近似最优值误差"]}


def check_plateau():
    cases = 0
    for width in range(1, 7):
        for count in range(width + 1):
            for selected in combinations(range(width), count):
                observations = {}
                for bits in product((0, 1), repeat=width):
                    key = tuple(bits[index] for index in selected)
                    observations.setdefault(key, Counter())[sum(bits) % 2] += 1
                for outcomes in observations.values():
                    if count < width:
                        assert outcomes[0] == outcomes[1]
                    else:
                        assert len(outcomes) == 1
                    cases += 1
    return {"conditional_histories": cases, "maximum_bits": 6}


def check_experiment_separation():
    models = list(product((0, 1), repeat=3))
    experiments = [lambda model, index=index: model[index] for index in range(3)]
    experiments.append(lambda model: model[0] ^ model[1])
    target = lambda model: model[0] ^ model[1]
    cases = 0
    for count in range(len(experiments) + 1):
        for subset in combinations(range(len(experiments)), count):
            groups = {}
            for model in models:
                observations = tuple(experiments[index](model) for index in subset)
                groups.setdefault(observations, set()).add(target(model))
            identifiable = all(len(values) == 1 for values in groups.values())
            separated = all(target(left) == target(right) or any(experiments[index](left) != experiments[index](right)
                            for index in subset) for left, right in combinations(models, 2))
            assert identifiable == separated
            cases += 1
    return {"experiment_subsets": cases, "models": len(models)}


def check_contextual_value():
    worlds = []
    for first, second, noise in product((0, 1), repeat=3):
        weight = Fraction(1, 4) * (Fraction(1, 4) if noise else Fraction(3, 4))
        worlds.append({'first': first, 'second': second, 'witness': first ^ second ^ noise,
                       'target': first ^ second, 'weight': weight})
    def success(fields):
        groups = {}
        for world in worlds:
            key = tuple(world[field] for field in fields)
            groups.setdefault(key, [Fraction(), Fraction()])[world['target']] += world['weight']
        return sum(max(masses) for masses in groups.values())
    assert success(['first']) == Fraction(1, 2)
    assert success(['witness']) == Fraction(3, 4)
    assert success(['second', 'first']) == 1
    assert success(['second', 'witness']) == Fraction(3, 4)
    return {'worlds': len(worlds), 'context_independent_ranking': False}


def affine_value(coefficients, point):
    return (coefficients[0] + sum(coefficient * coordinate
            for coefficient, coordinate in zip(coefficients[1:], point))) % 2


def check_affine_transfer():
    cases = 0
    for width in range(1, 5):
        points = list(product((0, 1), repeat=width))
        basis = [(0,) * width] + [tuple(int(coordinate == index) for coordinate in range(width)) for index in range(width)]
        for coefficients in product((0, 1), repeat=width + 1):
            labels = [affine_value(coefficients, point) for point in basis]
            recovered = (labels[0],) + tuple(label ^ labels[0] for label in labels[1:])
            assert recovered == coefficients
            assert all(affine_value(recovered, point) == affine_value(coefficients, point) for point in points)
            for changed in range(width + 1):
                modified = list(coefficients)
                modified[changed] ^= 1
                errors = sum(affine_value(modified, point) != affine_value(coefficients, point) for point in points)
                assert Fraction(errors, len(points)) == (1 if changed == 0 else Fraction(1, 2))
            cases += 1
        label_correctness = acceptance(3, Fraction(3, 4))
        all_correct = Fraction()
        for noise in product((0, 1), repeat=width + 1):
            recovered_error = (noise[0],) + tuple(value ^ noise[0] for value in noise[1:])
            count = sum(noise)
            weight = (1 - label_correctness) ** count * label_correctness ** (width + 1 - count)
            if not any(recovered_error):
                all_correct += weight
        assert all_correct == label_correctness ** (width + 1)
    return {"fully_recovered_functions": cases, "maximum_dimension": 4}


def check_transfer_coupling():
    cases = 0
    for horizon in range(1, 7):
        source_kernel = [[Fraction(3, 4), Fraction(1, 4)], [Fraction(1, 3), Fraction(2, 3)]]
        target_kernel = [[Fraction(2, 3), Fraction(1, 3)], [Fraction(1, 4), Fraction(3, 4)]]
        distributions = []
        for kernel in (source_kernel, target_kernel):
            paths = {(0,): Fraction(1)}
            for stage in range(horizon):
                expanded = {}
                for history, weight in paths.items():
                    for state, probability in enumerate(kernel[history[-1]]):
                        expanded[history + (state,)] = weight * probability
                paths = expanded
            distributions.append(paths)
        variation = sum(abs(distributions[0][history] - distributions[1][history]) for history in distributions[0]) / 2
        assert variation <= Fraction(horizon, 12)
        cases += 1
    return {"exact_path_distributions": cases, "single_step_tv": "1/12"}


def check_rule_selection():
    cases = 0
    for sample_size, first_risk, second_risk, confidence_failure in product(
        (20, 100, 300), (Decimal('0.1'),), (Decimal('0.4'), Decimal('0.8')), (Decimal('0.05'),)
    ):
        error_allowance = Decimal(2) * ((Decimal(4) / confidence_failure).ln() / (2 * sample_size)).sqrt()
        wrong_selection = Decimal(0)
        second_cdf = Decimal(0)
        for count in range(sample_size + 1):
            first_mass = Decimal(comb(sample_size, count)) * first_risk ** count * (1 - first_risk) ** (sample_size - count)
            second_mass = Decimal(comb(sample_size, count)) * second_risk ** count * (1 - second_risk) ** (sample_size - count)
            second_cdf += second_mass
            wrong_selection += first_mass * second_cdf
        if second_risk - first_risk > error_allowance:
            assert wrong_selection <= confidence_failure
        cases += 1
    weights = [Fraction(1), Fraction(2), Fraction(5)]
    tolerance = Fraction(1, 10)
    optimum = [tolerance * weight / sum(weights) for weight in weights]
    optimum_cost = -sum(float(weight) * log(float(error)) for weight, error in zip(weights, optimum))
    for left, right in combinations(range(len(weights)), 2):
        for direction in (-1, 1):
            changed = list(optimum)
            amount = min(changed[left], changed[right]) / 3
            changed[left] += direction * amount
            changed[right] -= direction * amount
            perturbed_cost = -sum(float(weight) * log(float(error)) for weight, error in zip(weights, changed))
            assert perturbed_cost >= optimum_cost - 1e-12
            cases += 1
    return {"selection_and_allocation_cases": cases, "selection_probability": "exact binomial sums; adversarial tie break"}


def write_data():
    directory = ROOT / 'data'
    directory.mkdir(exist_ok=True)
    rows = []
    probability = Decimal(3) / Decimal(4)
    tolerance = Decimal(1) / Decimal(20)
    margin = probability - Decimal('0.5')
    for length in (4, 8, 16, 32, 64, 128):
        required = (Decimal(length) / tolerance).ln() / (2 * margin ** 2)
        repeats = int(required.to_integral_value(rounding=ROUND_CEILING))
        repeats += int(repeats % 2 == 0)
        success = probability ** length
        attempts = int((tolerance.ln() / (1 - success).ln()).to_integral_value(rounding=ROUND_CEILING))
        assert (1 - success) ** attempts <= tolerance
        assert (1 - success) ** (attempts - 1) > tolerance
        assert Decimal(length) * (-2 * repeats * margin ** 2).exp() <= tolerance
        rows.append({'length': length, 'probability': str(probability), 'error_target': str(tolerance),
                     'local_repetitions': repeats, 'whole_attempts': attempts,
                     'whole_calls': length * attempts, 'local_calls': length * repeats})
    with (directory / 'separation.csv').open('w', newline='') as output:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    latex = ['{\\small', '\\begin{tabular}{rrrr}', '\\toprule',
             '$n$ & 局部重复 $r$ & 整条重试调用 & 局部保留调用\\\\', '\\midrule']
    for row in rows:
        formatted = [str(row['length']), str(row['local_repetitions'])]
        formatted.extend(format(row[key], ',').replace(',', r'\,') for key in ('whole_calls', 'local_calls'))
        latex.append(' & '.join(formatted) + r'\\')
    latex.extend(['\\bottomrule', '\\end{tabular}}', ''])
    (directory / 'separation-table.tex').write_text('\n'.join(latex))
    with (directory / 'plateau.csv').open('w', newline='') as output:
        writer = csv.writer(output)
        writer.writerow(['observed_bits', 'total_bits', 'optimal_success_probability'])
        for count in range(5):
            writer.writerow([count, 4, '1/2' if count < 4 else '1'])
    return rows


def main():
    with localcontext() as context:
        context.prec = 100
        report = {
            'edition': 2,
            'status': 'passed',
            'contract_amplification': check_contract_amplification(),
            'unknown_function_chain': check_unknown_chain(),
            'verification_and_shared_error': check_verification_lower_bound(),
            'abstraction': check_abstraction(),
            'value_plateau': check_plateau(),
            'experiment_design': check_experiment_separation(),
            'contextual_attention': check_contextual_value(),
            'affine_transfer': check_affine_transfer(),
            'coupling': check_transfer_coupling(),
            'rule_selection': check_rule_selection(),
            'budget_table': write_data(),
        }
    (ROOT / 'validation').mkdir(exist_ok=True)
    serialized = json.dumps(report, ensure_ascii=False, indent=2)
    (ROOT / 'validation/model-check.json').write_text(serialized + '\n')
    print(serialized)


if __name__ == '__main__':
    main()
