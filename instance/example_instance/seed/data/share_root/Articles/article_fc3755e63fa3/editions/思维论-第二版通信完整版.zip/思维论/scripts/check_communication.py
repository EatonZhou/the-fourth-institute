from collections import defaultdict
from fractions import Fraction
from itertools import combinations, product
from math import ceil, log2
from pathlib import Path
import csv
import json
import random


ROOT = Path(__file__).resolve().parents[1]


def marginal(distribution, fields):
    result = defaultdict(Fraction)
    for observation, probability in distribution.items():
        result[tuple(observation[index] for index in fields)] += probability
    return result


def entropy(distribution, fields):
    return -sum(float(probability) * log2(float(probability))
                for probability in marginal(distribution, fields).values() if probability)


def union_fields(*groups):
    return tuple(dict.fromkeys(index for group in groups for index in group))


def conditional_entropy(distribution, target, known):
    return entropy(distribution, union_fields(target, known)) - entropy(distribution, known)


def information(distribution, left, right, known=()):
    return (entropy(distribution, union_fields(left, known))
            + entropy(distribution, union_fields(right, known))
            - entropy(distribution, known)
            - entropy(distribution, union_fields(left, right, known)))


def bayes_logloss(distribution, target, known):
    joint = marginal(distribution, (target,) + known)
    context = marginal(distribution, known)
    return -sum(float(probability) * log2(float(probability / context[key[1:]]))
                for key, probability in joint.items() if probability)


def check_information_identities():
    generator = random.Random(20260913)
    cases = 0
    for repetition in range(100):
        weights = {state: generator.randrange(1, 10) for state in product(range(2), repeat=3)}
        normalizer = sum(weights.values())
        encoders = {}
        for source in range(2):
            counts = [generator.randrange(1, 10) for message in range(3)]
            encoders[source] = [Fraction(count, sum(counts)) for count in counts]
        distribution = {(source, target, side, message): Fraction(weight, normalizer) * encoders[source][message]
                        for (source, target, side), weight in weights.items() for message in range(3)}
        predicted_gain = information(distribution, (1,), (3,), (2,))
        actual_gain = bayes_logloss(distribution, 1, (2,)) - bayes_logloss(distribution, 1, (2, 3))
        assert abs(predicted_gain - actual_gain) < 1e-11
        total = information(distribution, (1,), (0,), (2,))
        residual = information(distribution, (1,), (0,), (2, 3))
        assert abs(total - predicted_gain - residual) < 1e-11
        assert predicted_gain <= information(distribution, (0,), (3,), (2,)) + 1e-11
        assert information(distribution, (0,), (3,), (2,)) <= conditional_entropy(distribution, (3,), (2,)) + 1e-11
        cases += 1
    xor = {(source, side, source ^ side): Fraction(1, 4) for source, side in product(range(2), repeat=2)}
    assert abs(information(xor, (2,), (0,))) < 1e-12
    assert abs(information(xor, (2,), (0,), (1,)) - 1) < 1e-12
    return {'random_finite_experiments': cases, 'seed': 20260913, 'xor_conditional_gain_bits': 1}


def binary_entropy(probability):
    return sum(-float(value) * log2(float(value)) for value in (probability, 1 - probability) if value)


def check_rate_distortion():
    rows = []
    for numerator in range(11):
        distortion = Fraction(numerator, 20)
        distribution = {}
        for target, side, error in product(range(2), repeat=3):
            weight = Fraction(1, 4) * (distortion if error else 1 - distortion)
            distribution[(target, side, target ^ error)] = weight
        actual_distortion = sum(weight for (target, side, received), weight in distribution.items() if target != received)
        actual_information = information(distribution, (0,), (2,), (1,))
        rate = 1 - binary_entropy(distortion)
        assert actual_distortion == distortion
        assert abs(actual_information - rate) < 1e-12
        rows.append({'error_probability': str(distortion), 'conditional_information_bits': rate})
    return rows


def chromatic_number(vertex_count, edges):
    for color_count in range(1, vertex_count + 1):
        for coloring in product(range(color_count), repeat=vertex_count):
            if all(coloring[left] != coloring[right] for left, right in edges):
                return color_count
    raise AssertionError('No coloring found')


def minimum_decodable_messages(vertex_count, support, targets):
    for message_count in range(1, vertex_count + 1):
        for encoding in product(range(message_count), repeat=vertex_count):
            table = {}
            valid = True
            for source, side in support:
                key = (encoding[source], side)
                target = targets[(source, side)]
                if key in table and table[key] != target:
                    valid = False
                    break
                table[key] = target
            if valid:
                return message_count
    raise AssertionError('No decoder found')


def check_coloring():
    cases = 0
    for masks in product((1, 2, 3), repeat=3):
        support = {(source, side) for source in range(3) for side in range(2) if masks[source] & (1 << side)}
        for outputs in product(range(2), repeat=6):
            targets = {(source, side): outputs[2 * source + side] for source, side in support}
            edges = [(left, right) for left, right in combinations(range(3), 2)
                     if any((left, side) in support and (right, side) in support
                            and targets[(left, side)] != targets[(right, side)] for side in range(2))]
            assert chromatic_number(3, edges) == minimum_decodable_messages(3, support, targets)
            cases += 1
    cycle_edges = [(vertex, (vertex + 1) % 5) for vertex in range(5)]
    assert chromatic_number(5, cycle_edges) == 3
    cycle_distribution = {(source, side): Fraction(1, 10) for side in range(5) for source in (side, (side + 1) % 5)}
    assert abs(conditional_entropy(cycle_distribution, (0,), (1,)) - 1) < 1e-12
    colors = ['a', 'b', 'a', 'b', 'c']
    rows = []
    for source, side in sorted(cycle_distribution):
        possible = [candidate for candidate in (side, (side + 1) % 5) if colors[candidate] == colors[source]]
        assert possible == [source]
        rows.append({'sender_observation': source, 'receiver_side_information': side,
                     'message': colors[source], 'decoded_target': possible[0]})
    return {'finite_support_and_target_instances': cases, 'cycle_chromatic_number': 3,
            'cycle_conditional_entropy_bits': 1, 'cycle_fixed_binary_length': 2}, rows


def check_request_feedback():
    pairs = 0
    decoded = 0
    for width in range(1, 9):
        strings = list(product(range(2), repeat=width))
        for left, right in combinations(strings, 2):
            assert any(left[index] != right[index] for index in range(width))
            pairs += 1
        for source in strings:
            for index in range(width):
                request_bits = ceil(log2(width))
                request = format(index, f'0{request_bits}b') if request_bits else ''
                recovered_index = int(request, 2) if request else 0
                assert len(request) == request_bits
                assert source[recovered_index] == source[index]
                decoded += 1
    return {'conflicting_input_pairs': pairs, 'request_response_decodings': decoded,
            'n8_one_way_bits': 8, 'n8_request_response_bits': 4}


def check_gating():
    generator = random.Random(20260914)
    cases = 0
    for repetition in range(100):
        weights = {}
        for target, side in product(range(2), repeat=2):
            weights[(target, side, 0, -1)] = generator.randrange(1, 10)
            for payload in range(2):
                weights[(target, side, 1, payload)] = generator.randrange(1, 10)
        distribution = {state: Fraction(weight, sum(weights.values())) for state, weight in weights.items()}
        send_probability = sum(probability for state, probability in distribution.items() if state[2])
        sent = {state: probability / send_probability for state, probability in distribution.items() if state[2]}
        total = information(distribution, (0,), (2, 3), (1,))
        gate = information(distribution, (0,), (2,), (1,))
        content = information(sent, (0,), (3,), (1,))
        assert abs(total - gate - float(send_probability) * content) < 1e-11
        chain = information(distribution, (0,), (2,), (1,)) + information(distribution, (0,), (3,), (1, 2))
        assert abs(total - chain) < 1e-11
        cases += 1
    for always_send in (0, 1):
        boundary = {(target, 0, always_send, target if always_send else -1): Fraction(1, 2) for target in (0, 1)}
        assert abs(information(boundary, (0,), (2, 3), (1,)) - always_send) < 1e-12
    sparse = {(0, 0, 0, -1): Fraction(1, 2), (1, 0, 1, 1): Fraction(1, 2)}
    assert abs(information(sparse, (0,), (2,), (1,)) - 1) < 1e-12
    return {'random_gated_distributions': cases, 'boundary_cases': 2, 'silent_or_sent_mark_carries_one_bit': True}


def check_selective_sending():
    candidates = 0
    prior_cost_cases = 0
    for probability, price in product((Fraction(index, 10) for index in range(11)),
                                      (Fraction(index, 4) for index in range(13))):
        best = None
        for send_zero, send_one in product((Fraction(index, 10) for index in range(11)), repeat=2):
            silent_zero = (1 - probability) * (1 - send_zero)
            silent_one = probability * (1 - send_one)
            loss = min(silent_zero, silent_one) + price * (1 - silent_zero - silent_one)
            best = loss if best is None else min(best, loss)
            candidates += 1
        assert best == min(probability, 1 - probability) * min(1, price)
        prior_cost_cases += 1
    return {'prior_and_price_pairs': prior_cost_cases, 'randomized_gate_grid_points': candidates,
            'exercise_losses': {'always_silent': '1/10', 'always_send': '1/2', 'rare_value_only': '1/20'}}


def write_csv(path, rows):
    with path.open('w', newline='') as output:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    coloring, decoder_rows = check_coloring()
    rates = check_rate_distortion()
    report = {
        'status': 'passed', 'scope': '通信章节的有限模型；一般结论由正文证明',
        'information_identities': check_information_identities(),
        'binary_rate_distortion': rates,
        'side_information_coloring': coloring,
        'request_feedback': check_request_feedback(),
        'gating_information': check_gating(),
        'optimal_selective_sending': check_selective_sending(),
    }
    (ROOT / 'data').mkdir(exist_ok=True)
    write_csv(ROOT / 'data/communication-cycle-decoder.csv', decoder_rows)
    write_csv(ROOT / 'data/communication-rate-distortion.csv', rates)
    serialized = json.dumps(report, ensure_ascii=False, indent=2)
    (ROOT / 'validation/communication-check.json').write_text(serialized + '\n')
    print(serialized)


if __name__ == '__main__':
    main()
