from collections import Counter
import json
from pathlib import Path
import re


def main():
    root = Path(__file__).resolve().parents[1]
    sources = sorted(root.glob("*.tex")) + sorted((root / "chapters").glob("*.tex")) + sorted((root / "appendices").glob("*.tex")) + sorted((root / "data").glob("*.tex"))
    text = "\n".join(path.read_text() for path in sources)
    bibliography = (root / "references.bib").read_text()
    keys = set(re.findall(r"@\w+\{([^,]+),", bibliography))
    cited = {key.strip() for group in re.findall(r"\\cite\w*(?:\[[^]]*\])*\{([^}]+)\}", text) for key in group.split(",")}
    assert cited <= keys, f"Missing bibliography entries: {cited - keys}"
    labels = re.findall(r"\\label\{([^}]+)\}", text)
    duplicate_labels = [name for name, count in Counter(labels).items() if count > 1]
    assert not duplicate_labels, duplicate_labels
    references = set(re.findall(r"\\(?:ref|eqref|pageref|autoref)\{([^}]+)\}", text))
    assert references <= set(labels), f"Missing labels: {references - set(labels)}"
    includes = re.findall(r"\\(?:input|include)\{([^}]+)\}", text)
    for include in includes:
        assert (root / (include + ".tex")).exists(), include
    for source in sources:
        content = source.read_text()
        assert content.count(r"\[") == content.count(r"\]"), source.name
        assert content.count(r"\(") == content.count(r"\)"), source.name
        stack = []
        for match in re.finditer(r"\\(begin|end)\{([^}]+)\}", content):
            direction, environment = match.groups()
            if direction == "begin":
                stack.append(environment)
            else:
                assert stack and stack.pop() == environment, (source.name, environment)
        assert not stack, (source.name, stack)
    assert len(list((root / "chapters").glob("*.tex"))) == 16
    assert len(list((root / "appendices").glob("*.tex"))) == 3
    assert not re.search(r"TODO|FIXME|待补|占位", text)
    result = {
        "edition": 2,
        "status": "passed",
        "chapters": 16,
        "appendices": 3,
        "chinese_characters": len(re.findall(r"[\u4e00-\u9fff]", text)),
        "theorems": len(re.findall(r"\\begin\{theorem\}", text)),
        "propositions": len(re.findall(r"\\begin\{proposition\}", text)),
        "lemmas": len(re.findall(r"\\begin\{lemma\}", text)),
        "corollaries": len(re.findall(r"\\begin\{corollary\}", text)),
        "proofs": len(re.findall(r"\\begin\{proof\}", text)),
        "exercises": len(re.findall(r"\\begin\{exercise\}", text)),
        "figures": len(re.findall(r"\\begin\{figure\}", text)),
        "references": len(cited),
    }
    serialized = json.dumps(result, ensure_ascii=False, indent=2)
    (root / "validation/manuscript-check.json").write_text(serialized + "\n")
    print(serialized)


if __name__ == "__main__":
    main()
